//
//  XTHWDecoder.m
//  VideoToolBoxSample
//
//  Created by 陈耀武 on 2020/8/3.
//  Copyright © 2020 陈耀武. All rights reserved.
//

#import "XTHWDecoder.h"

@interface XTHWDecoder () {
    VTDecompressionSessionRef       _decoderSession;
    CMVideoFormatDescriptionRef     _decodeFormatDesc;

    uint8_t *_sps;
    NSInteger _spsSize;
    uint8_t *_pps;
    NSInteger _ppsSize;
}
@end

@implementation XTHWDecoder

- (BOOL)initXTHWDecoder {
    if (_decoderSession) {
        return YES;
    }
    
    return YES;
}


@end
