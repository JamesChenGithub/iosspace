//
//  main.m
//  testFrameExtractor
//
//  Created by htaiwan on 10/24/14.
//  Copyright (c) 2014 appteam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
